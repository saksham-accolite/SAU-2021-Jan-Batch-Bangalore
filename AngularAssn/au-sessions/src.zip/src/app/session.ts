export interface Session {
    name: string;
    trainer: string;
    date: Date;
  }